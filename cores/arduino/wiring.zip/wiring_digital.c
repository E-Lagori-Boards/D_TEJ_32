// See LICENSE file for license details.

#include "Arduino.h"

__BEGIN_DECLS

void
pinMode(uint32_t pin, uint32_t mode)
{
  
}


void
digitalWrite(uint32_t pin, uint32_t val)
{
 

}

int
digitalRead(uint32_t pin)
{

}

__END_DECLS
