/*
 */

#include "TimerOne.h"
#include "Arduino.h"
#include "wiring_private.h"
#include "encoding.h"
#include <string.h>

extern volatile unsigned long INTERRUPT_Handler_0;
extern volatile unsigned long trap_entry;

unsigned short TimerOne::pwmPeriod = 0;
unsigned char TimerOne::clockSelectBits = 0;

TimerOne Timer1(1);              // preinstatiate


TimerOne::TimerOne(uint32_t _id) :
		id(_id) {

}

// interrupt service routine that wraps a user defined function supplied by attachInterrupt

void TimerOne::isr_timer(void) {
	unsigned int EOI = TIMER_REG(id,TIMER_REG_EOI);//clear timer interrupt
	//unsigned int EOI = Timer(timer_no).EOI;
	isrCallback();
}

//****************************
//  Configuration
//****************************
void TimerOne::initialize(unsigned long microseconds)
{
	setPeriod(microseconds);
}

void TimerOne::setPeriod(unsigned long microseconds) {
	const unsigned long cycles = microseconds * ratio;

	TIMER_REG(id,TIMER_REG_EOI) = 0x0;	// Disable timer.
	TIMER_REG(id,TIMER_REG_LoadCount) = cycles;	// Load timer with no of clocks.

//	Timer(timer_no).Control = 0x0;			// Disable timer.
//	Timer(timer_no).LoadCount = cycles;	// Load timer with no of clocks.

}

//****************************
//  Run Control
//****************************
void TimerOne::start() {
	TIMER_REG(id,TIMER_REG_Control) = 0x03;		// Enable timer with intr unmasked.
	//Timer(timer_no).Control = 0x03;
}
void TimerOne::stop() {
	TIMER_REG(id,TIMER_REG_Control) = 0x0;		// Disable timer.
	//Timer(timer_no).Control = 0x0;
}
void TimerOne::restart() {
	TIMER_REG(id,TIMER_REG_Control) = 0x03;		// Enable timer with intr unmasked.
	//Timer(timer_no).Control = 0x03;
}
void TimerOne::resume() {
	TIMER_REG(id,TIMER_REG_Control) = 0x03;		// Enable timer with intr unmasked.
	//Timer(timer_no).Control = 0x03;			// Enable timer with intr unmasked.
}


//****************************
//  Interrupt Function
//****************************

void TimerOne::attachInterrupt(void (*isr)(), unsigned long microseconds)
{
	if (microseconds > 0)
		setPeriod(microseconds);
	attachInterrupt(isr);
}
void TimerOne::detachInterrupt() {
	TIMER_REG(id,TIMER_REG_Control) = 0x0;		// Disable timer.
	//Timer(timer_no).Control = 0x0;			// Disable timer.
	__asm__ __volatile__ ("fence");
}

/*
 * \brief Specifies a named Interrupt Service Routine (ISR) to call when an interrupt occurs.
 *        Replaces any previous function that was attached to the interrupt.
 */

void TimerOne::attachInterrupt(void (*isr)())  {

	int intr_number = 7 + id;
	// Should be enableInterrupt()
	// *************************Interrupt Enable*************************** //
	set_csr(mie, MIP_MEIP);	// Set MEIE bit in MIE register for Machine External Intr.
	set_csr(mstatus, MSTATUS_MIE);// Set global machine intr bit (3rd bit) in MSTATUS register.
	write_csr(mtvec, (uint32_t) &INTERRUPT_Handler_0);// Set MTVEC register with vector address.
	MACHINE_INT_ENABLE |= ((unsigned long) 1 << intr_number);// Enable interrupt for peripheral in interrupt controller.
	__asm__ __volatile__ ("fence");
	// *************************Register IRQ Handler*************************** //

	irq_table[intr_number] = isr;

	isrCallback = isr;

	TIMER_REG(id,TIMER_REG_Control) = 0x03;		// Enable timer with intr unmasked.
	//Timer(timer_no).Control = 0x03;
}

void TimerOne::interrupt_handler(void) {

	void (*func_ptr)();
	int mcause_val = 0, trap_type = 0;

	trap_type = (read_csr(mcause) >> 31);

	if (trap_type) { //Interrupt

		mcause_val = ((read_csr(mcause) << 1) >> 1);

		if (mcause_val == 3) { // Machine software interrupt
			clear_csr(mip, MIP_MSIP);// Clear MSIP bit in MIP register for Machine
			sw_irq_function(); // Invoke the peripheral handler as function pointer.
		} else {

			unsigned long intr_status = MACHINE_INT_STATUS; // Read interrupt status register.

			for (unsigned long i = 0; i < MAXIMUM_INTR_COUNT; i++) /*MAXIMUM_INTR_COUNT*/
			{
				if ((intr_status >> i) & (unsigned long) 1) {
					irq_table[i](); // Invoke the peripheral handler as function pointer.
				}
			}
		}
	} else { //Exception
		func_ptr = (void (*)()) (&trap_entry); //jump to exception handler
		func_ptr();
	}
}

